INSERT INTO koerier
VALUES(null, "De Fietskoeriers", 1);

INSERT INTO tarief
VALUES(null, 1, 9, 0, 4 );

INSERT INTO tarief
VALUES(null, 1, 14, 0, 8 );

INSERT INTO tarief
VALUES(null, 1, 19, 0, 12 );

INSERT INTO tarief
VALUES(null, 1, 15, 0.56, 0 );

INSERT INTO koerier
VALUES(null, "Bodekoeriers", 0);

INSERT INTO tarief
VALUES(null, 2, 12.5, 0, 40 );

INSERT INTO tarief
VALUES(null, 2, 0, 0.4, 0 );

INSERT INTO koerier
VALUES(null, "Pietersen Transport BV", 0);

INSERT INTO tarief
VALUES(null, 3, 10, 0, 25 );

INSERT INTO tarief
VALUES(null, 3, 0, 0.39, 0 );


INSERT INTO Koerier
VALUES(null, "Treinkoerier", 0);

INSERT INTO Tarief
VALUES(null, 4, 2, 0, 999999);