<?php

namespace model;

class Treinreiziger extends Koerier{
    
}
