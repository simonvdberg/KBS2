
INSERT INTO Koerier
VALUES(null, "De Fietskoeriers");

INSERT INTO Tarief
VALUES(null, 1, 9, 0, 4 );

INSERT INTO Tarief
VALUES(null, 1, 14, 0, 8 );

INSERT INTO Tarief
VALUES(null, 1, 19, 0, 12 );

INSERT INTO Tarief
VALUES(null, 1, 15, 0.56, 0 );

INSERT INTO Koerier
VALUES(null, "Bodekoeriers");

INSERT INTO Tarief
VALUES(null, 2, 12.5, 0, 40 );

INSERT INTO Tarief
VALUES(null, 2, 0, 0.4, 0 );

INSERT INTO Koerier
VALUES(null, "Pietersen Transport BV");

INSERT INTO Tarief
VALUES(null, 3, 10, 0, 25 );

INSERT INTO Tarief
VALUES(null, 3, 0, 0.39, 0 );
